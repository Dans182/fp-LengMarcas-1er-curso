/*
Función para simular o envío de datos do formulario.
Recolle o enviado e o amosa por pantalla
*/
function displayFormContents(someForm) {
  var out = "Datos enviados:\n--------------\n"
  for (var i = 0, el; (el = someForm.elements[i]); i++) {
    if (el.type === "radio" && el.checked) {
      out += el.name + " = " + el.value + "\n"
    } else if (el.type === "checkbox" && el.checked) {
      out += el.name + " = " + el.value + "\n"
    } else if (el.type !== "radio" && el.type !== "checkbox" && el.name) {
      out += el.name + " = " + el.value + "\n"
    }
  }
  alert(out)
}
